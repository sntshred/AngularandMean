package com.nis.employee;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class UpdateEmployee extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public UpdateEmployee() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		updateEmployee(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		updateEmployee(request,response);
	}

	private void updateEmployee(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		try {
			String callBack = request.getParameter("callback");
			String empID = request.getParameter("id");
			String firstName = request.getParameter("fn");
			String lastName = request.getParameter("ln");
			String salary = request.getParameter("sal");
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/nit_hibernate", "root", "vishwas7890");
			PreparedStatement st = con.prepareStatement("UPDATE employee_sql SET first_name = ?,last_name = ?,salary = ? WHERE id = ?");
			st.setString(1, firstName);
			st.setString(2, lastName);
			st.setDouble(3, Double.parseDouble(salary));
			st.setInt(4, Integer.parseInt(empID));
			int flag = st.executeUpdate();
			System.out.println("flag + "+flag+"\nsql :: "+st);
			st.close();
			con.close();
			JSONObject obj = new JSONObject();
			if(flag>0)
				obj.put("flag", "success");
			else
				obj.put("flag", "fail");
			response.setContentType("text/javascript");
			PrintWriter out = response.getWriter();
			out.println(callBack+"("+obj+")");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occure
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
