package com.nit.studet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentDetails
 */
public class StudentDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String callback = request.getParameter("callback");
		String data = "[" +
				"{'Name' : 'Naresh IT Student 1','RollNo' : 101,'Percentage' : '80%'}," +
				"{'Name' : 'Naresh IT Student 2','RollNo' : 201,'Percentage' : '70%'}," +
				"{'Name' : 'Naresh IT Student 3','RollNo' : 301,'Percentage' : '75%'}," +
				"{'Name' : 'Naresh IT Student 4','RollNo' : 401,'Percentage' : '77%'}" +
				"]";
		String jsonpResponse = callback + "(" + data +");";
		
		response.setContentType("text/javascript");
		PrintWriter out = response.getWriter();
		out.println(jsonpResponse);
		//out.println(data);
		out.flush();
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
